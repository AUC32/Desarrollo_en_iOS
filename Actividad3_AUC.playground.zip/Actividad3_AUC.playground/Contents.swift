import UIKit

//Declara cuatro variables con 3 diferentes tipos de datos, cada uno que corresponda a un número entero, un número decimal, una cadena de texto, realizando la asignación explícita y la asignación inferida

//Entero declarativo
let entero:Int=1
let entero1:Int=2
let entero2:Int=3
let entero3:Int=4

//Flotante declarativo
let float:Float = 1.5
let float1:Float = 2.5
let float2:Float = 3.5
let float3:Float = 4.5

//Cadena declarativo
let string:String="Hola"
let string1:String="estoy"
let string2:String="programando"
let string3:String="en iOS"

//Entero inferencia
var Entero1 = 5
var Entero2 = 6
var Entero3 = 7
var Entero4 = 8

//Flotante inferencia
var Float1 = 5.5
var Float2 = 6.5
var Float3 = 7.5
var Float4 = 8.5

//Cadena inferencia
var Cadena = "abc"
var Cadena1 = "dfg"
var Cadena2  = "hij"
var Cadena3 =  "klm"

//Declara el tipo de dato por asociación para un tipo de dato String

let e:String = String()

//Declara el tipo de dato por asocación para un tipo de dato Número Entero

let f:Int = Int()


//Arreglos y Diccionarios
//Crea la variable "numeros" de tipo Array con números consecutivos del 1 a 10

var numeros:Array<Int> = Array<Int>()
numeros.append(1)
numeros.append(2)
numeros.append(3)
numeros.append(4)
numeros.append(5)
numeros.append(6)
numeros.append(7)
numeros.append(8)
numeros.append(9)
numeros.append(10)


//Crea la variable "diasdelaSemana" de tipo Dictionary con la relaciòn numero:día Ej. 1:Lunes

var diasdelaSemana:Dictionary<Int, String> = Dictionary<Int, String>()
diasdelaSemana = [1:"Lunes"]
diasdelaSemana = [2:"Martes"]
diasdelaSemana = [3:"Miércoles"]
diasdelaSemana = [4:"Jueves"]
diasdelaSemana = [5:"Viernes"]
diasdelaSemana = [6:"Sábado"]
diasdelaSemana = [7:"Domingo"]

