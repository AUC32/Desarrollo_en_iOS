import UIKit

/*:
# Playground - Actividad 7
* Valor por tipo y por referencia
* Funciones personalizadas Y Genericos
* Funciones de la biblioteca Swift para Arreglos
*/

/*:
### Valor por tipo y por referencia
A) Para la colección "var costo_referencia:[Float] = [8.3,10.5,9.9]", aplicar el impuesto del 16% a través de recorrer la colección "costo_referencia" para aplicar el impuesto a cada cantidad, crear una función Impuesto que recibe como parámetro la colección y regrese aplicado el impuesto a cada cantidad.
*/

var costo_referencia:[Float]=[8.3,10.5,9.9]
var indice:Int = 0

func impuesto(arreglo:[Float]) -> [Float]{
    var resultado:[Float] = []
    for i in arreglo{
        resultado.append(Float(i)*1.16)
    }
    return resultado
}

impuesto(arreglo: costo_referencia)

//: B) Crear la función "sumaTres"  que reciba una función con dos valores a sumar y un segundo parametro para sumar el tercer número.

var suma = {(x:Int, y:Int) -> Int in return x+y}

suma(2,2)

func sumaTres(a:Int, b:Int, c:Int) -> Int{
    return suma(a,b)+c
}

sumaTres(a: 2, b: 2, c: 2)



/*:
### Funciones personalizadas y Genéricos

 
 A) Generics: Crear la función genérica para intercambiar valores entre dos variables del mismo tipo.
*/

func CambioFloat(a:Float, b:Float) -> (Float, Float){
    var a:Float = a
    var b:Float = b
    
    let tempFloat = a
    a=b
    b=tempFloat
    return(a,b)
}

print(CambioFloat(a: 3, b: 4))

//: B) Función personalizada: Crear la función "Transformar" que reciba como parámetro una colección de tipo Int  "var datos = [3,7,9,2]" y una función que transforme cada valor de la coleción en una operación definida fuera de la función, regresando una colección transformada.

extension Array{
    func Transformar<T> (inicial:T, acumula:(T,Element)->T)->T{
        var respuesta:T = inicial
        for valor in self{
            respuesta = acumula(respuesta,valor)
        }
        return respuesta
    }
    func Transform2 (datos1:[Int], datos2:[Int]) -> ([Int],[Int]){
        var datos1:[Int] = datos1
        var datos2:[Int] = datos2
        
        let Array2 = datos1
        datos1 = datos2
        datos2 = Array2
        return (datos1,datos2)
    }
}

var arreglo = [3,7,9,2]

arreglo.Transformar(inicial:0){(a,b) in a+b}
print(arreglo.Transform2(datos1: arreglo, datos2: arreglo.map{$0*2}))

/*:
### Biblioteca de Swift
A) Aplicar la función de librería de Swift "map" para la colección var precios = [4.2, 5.3, 8.2, 4.5] y aplicar el impuesto de 16% y asignarla a la variable "impuesto"
*/

var precios = [4.2, 5.3, 8.2, 4.5]
var impuesto = precios.map{a in return a*1.16}

impuesto

//: B) Aplicar la función de la librería de Swift "filter" para la colección resultante "impuesto" del paso A, en donde se obtengas solo los precios mayores a 6.0 y asignarlos a la variable "precio_menor"

var precio_menor = impuesto.filter{a in a>6.0}

precio_menor
