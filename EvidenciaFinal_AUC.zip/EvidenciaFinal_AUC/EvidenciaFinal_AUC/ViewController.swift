//
//  ViewController.swift
//  EvidenciaFinal_AUC
//
//  Created by user183807 on 5/20/21.
//  Copyright © 2021 user183807. All rights reserved.
//

import UIKit
import SafariServices


class ViewController: UIViewController {
    
    
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
         
        
    }
    
    
    @IBAction func buttonTapped(){
        
        let vc = SFSafariViewController(url:URL(string:"https://www.eluniversal.com.mx")!)
        
        present (vc,animated:true)
        
    }
    
    @IBAction func share(_ sender:Any){
        
        let activityVC = UIActivityViewController(activityItems: ["https://github.com/AUC32/Desarrollo_en_iOS/blob/main/EvidenciaFinal_AUC.zip"], applicationActivities: nil)
        activityVC.popoverPresentationController?.sourceView = self.view
        
        self.present(activityVC,animated: true, completion: nil)
        
    }
    
   @IBAction func buttonTappedTwo(){
       
    
    
    let vc_two = SFSafariViewController(url:URL(string:"https://www.google.com/maps?client=firefox-b-d&q=universidad+tecmilenio+campus+ferrer%C3%ADa&um=1&ie=UTF-8&sa=X&ved=2ahUKEwjottDnl9vwAhVDLKwKHXQ-DEcQ_AUoAXoECAEQAw")!)
       
       present (vc_two,animated:true)
    
    
    
       
   }
    
    
}


