//
//  Contacto.swift
//  EvidenciaFinal_AUC
//
//  Created by user183807 on 5/21/21.
//  Copyright © 2021 user183807. All rights reserved.
//

import Foundation
import SafariServices


class Contacto: UIViewController {
    
    

override func viewDidLoad() {
    
    super.viewDidLoad()
     
    
    }
    
    @IBAction func buttonTappedTwo(){
        
        let vc_two = SFSafariViewController(url:URL(string:"https://www.google.com/maps?client=firefox-b-d&q=universidad+tecmilenio+campus+ferrer%C3%ADa&um=1&ie=UTF-8&sa=X&ved=2ahUKEwjottDnl9vwAhVDLKwKHXQ-DEcQ_AUoAXoECAEQAw")!)
        
        present (vc_two,animated:true)
        
        
        
    }
    
}
