//
//  ViewController.swift
//  GestoAnimacion
//
//  Created by alicharlie on 11/05/16.
//  Copyright © 2016 codepix. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tipoGesto: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let gestoTap = UITapGestureRecognizer(target: self, action:#selector(self.accionGesto(_:)))

        let gestoSwipe = UISwipeGestureRecognizer(target: self, action:#selector(self.accionGesto(_:)))

        self.view.addGestureRecognizer(gestoTap)
        self.view.addGestureRecognizer(gestoSwipe)
        
    
    }
    
    
    @objc func accionGesto(_ sender: UIGestureRecognizer){
    if sender is UITapGestureRecognizer{
    tipoGesto.text = "Tap"
    }
    if sender is UISwipeGestureRecognizer{
    tipoGesto.text = "Swipe"
    }
    animacion()
    }

    

        
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.tipoGesto.alpha = 1.0

    
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
        
    }

    
    func animacion(){
    UIView.animate(withDuration: 3, delay: 0.2, options: [], animations: {
        self.tipoGesto.alpha = 1.0
    }) { _ in
        self.tipoGesto.alpha = 0.0
    }
    }
    

}



