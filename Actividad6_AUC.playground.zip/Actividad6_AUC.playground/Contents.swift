import UIKit

//Crea el operador para realizar la potencia del valor "a" a la potencia "b" en valores enteros.

infix operator ^^^

func ^^^(a:Int, b:Int) -> Double{
    return pow(Double(a), Double(b))
}

2^^^4

//Crear el operador |> para ordenar la colección [2,5,3,4] de menor a mayor.

prefix operator |>

prefix func |>(datos:[Int]) -> [Int]{
    let sortedData = datos.sorted()
    return sortedData
}

|>[2,5,3,4]


//Del conjunto de datos en el Array [2,3,4,5], crea el subscript para modificar los valores multiplcados por el valor 2 y extrae el valor dado un índice.

var arreglo = [2,3,4,5]

class Ejercicio3 {
    var vals:[Int]
    init(v:[Int]){
        self.vals = v
    }
    subscript(idx:Int) -> Int{
        get{
            return vals[idx]
        }
        set(val2){
            vals[idx] = val2
        }
    }
}

let multiplicacion = Ejercicio3(v:arreglo)
let array = multiplicacion.vals.map{$0 * 2}
array[1]

//Crear el Struct para definir u obtener la posición para los personajes de tipo Enemigo donde cada posición es de tipo CGPoint aplicando subscripts.

struct posicion {
    var x:CGPoint
    var y:CGPoint
    var ubi:(CGPoint,CGPoint)
    
    func lugar() -> (CGPoint, CGPoint){
        let ubi = (self.x, self.y)
        return ubi
    }
    subscript (idx:CGPoint) -> (CGPoint, CGPoint){
        get{
            return ubi
        }
        set(ubi2){
            ubi = ubi2
        }
    }
}


//Crea la función ExisteValor en la cual se reciba como parámetro el valor a buscar dentro de una colección ["A":1,"B":2,"C":3]

let cole = ["A":1,"B":2,"C":3]

func ExisteValor(idx:String){
    guard let existe = cole[idx] else {
        print ("No existe")
        return
    }
    print("existe \(existe)")
}

ExisteValor(idx:"D")
cole["D"]
