//
//  ViewController.swift
//  Actividad10_AUC
//
//  Created by user183807 on 4/12/21.
//  Copyright © 2021 user183807. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

