import UIKit

//Para condicionales y ciclos, declara la variable datos con los valores [3,6,9,2,4,1], realiza el recorrido de la variable datos con la instrucción for y encuentra los valores menores a 5

let datos = [3,6,9,2,4,1]

for datos in 1..<5 {
    print(datos)
}

//Para funciones, crea la función suma que reciba dos parámetros de tipo entero regresando la suma de ambos números y crea la función potencia que reciba dos parámetros de tipo entero, el primer parámetro para el número base y el segundo la potencia a elevar, regresando el resultado de la potencia.

func suma(a:Int, b:Int) -> Int{
    let suma1 = a + b
    
    print ("El resultado de la suma es: \(suma1)")
    
    return suma1
}

suma (a:5, b:2)

func potencia (_ base:Int, _ potencia:UInt) -> Int{
    var respuesta: Int = 1
    for _ in 0..<potencia { respuesta *= base }
    return respuesta
}

let resultado = pow(2,2)

print ("El resultado de la potencia es:  \(resultado)")


//Para enumeraciones, crea la enumeración meses para definir tipos de datos basados en los meses del año y crea la función numeroMes que reciba el tipo de dato meses y regrese el número del mes correspondiente. Para regresar el número de mes correspondiente utiliza switch.

enum meses{
    case Enero
    case Febrero
    case Marzo
    case Abril
    case Mayo
    case Junio
    case Julio
    case Agosto
    case Septiembre
    case Octubre
    case Noviembre
    case Diciembre
}

var mes1:meses
mes1 = .Enero

switch mes1 {
case .Enero:
    print("Este es el mes 1")
case .Febrero:
    print ("Este es el mes 2")
case .Marzo:
    print ("Este es el mes 3")
case .Abril:
    print ("Este es el mes 4")
case .Mayo:
    print ("Este es el mes 5")
case .Junio:
    print ("Este es el mes 6")
case .Julio:
    print ("Este es el mes 7")
case .Agosto:
    print ("Este es el mes 8")
case .Septiembre:
    print ("Este es el mes 9")
case .Octubre:
    print ("Este es el mes 10")
case .Noviembre:
    print ("Este es el mes 11")
case .Diciembre:
    print ("Este es el mes 12")
default:
    print("Elige uno de los meses por favor")
}



